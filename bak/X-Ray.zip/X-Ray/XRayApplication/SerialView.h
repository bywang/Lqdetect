// SerialView.h : interface of the CSerialView class
//
/////////////////////////////////////////////////////////////////////////////
//{{AFX_INCLUDES()
#include "mscomm.h"
//}}AFX_INCLUDES

#if !defined(AFX_SERIALVIEW_H__EADEB4D6_1AB8_4F37_B3D8_88E432313113__INCLUDED_)
#define AFX_SERIALVIEW_H__EADEB4D6_1AB8_4F37_B3D8_88E432313113__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CSerialView : public CFormView
{
protected: // create from serialization only
	CSerialView();
	DECLARE_DYNCREATE(CSerialView)

public:
	//{{AFX_DATA(CSerialView)
	enum { IDD = IDD_SERIAL_FORM };
	CEdit	m_CheckFaults;
	CEdit	m_TempMon;
	CEdit	m_maMon;
	CEdit	m_kvMon;
	CButton	m_EnableXRay;
	CButton	m_mAProgram;
	CButton	m_kvProgram;
	CEdit	m_Version;
	CMSComm	m_comm;
	//}}AFX_DATA

// Attributes
public:
	CSerialDoc* GetDocument();

// Operations
public:
	BOOL WaitForResponse(int BufferLength);
	void CheckVersion();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSerialView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSerialView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CSerialView)
	afx_msg void OnClose();
	afx_msg void OnCheckXray();
	afx_msg void OnClearFaults();
	afx_msg void OnTimer(UINT nIDEvent);
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in SerialView.cpp
inline CSerialDoc* CSerialView::GetDocument()
   { return (CSerialDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SERIALVIEW_H__EADEB4D6_1AB8_4F37_B3D8_88E432313113__INCLUDED_)
