//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Serial.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_SERIAL_FORM                 101
#define IDR_MAINFRAME                   128
#define IDR_SERIALTYPE                  129
#define IDC_EDIT1                       1000
#define IDC_EDIT_KVmon                  1000
#define IDC_EDIT2                       1001
#define IDC_EDIT_mAMON                  1001
#define IDC_MSCOMM1                     1002
#define IDC_BUTTON1                     1003
#define IDC_BUTTON_READ                 1003
#define IDC_MSCOMM2                     1004
#define IDC_COMBO4                      1009
#define IDC_COMBO5                      1010
#define IDC_BUTTON2                     1011
#define IDC_CHECK_KV                    1012
#define IDC_CHECK_mA                    1013
#define IDC_CHECK_XRAY                  1014
#define IDC_EDIT_TempMon                1015
#define IDC_EDIT_VERSION                1016
#define IDC_EDIT_CHECKFAULTS            1017
#define IDC_BUTTON3                     1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
