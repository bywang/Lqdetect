// SerialView.cpp : implementation of the CSerialView class
//

#include "stdafx.h"
#include "Serial.h"

#include "SerialDoc.h"
#include "SerialView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BOOL ERROR_CHECK = FALSE;
BOOL InsideTimer = FALSE;


// CSerialView

IMPLEMENT_DYNCREATE(CSerialView, CFormView)

BEGIN_MESSAGE_MAP(CSerialView, CFormView)
	//{{AFX_MSG_MAP(CSerialView)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_CHECK_XRAY, OnCheckXray)
	ON_BN_CLICKED(IDC_BUTTON3, OnClearFaults)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CFormView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////

// CSerialView construction/destruction

CSerialView::CSerialView()
	: CFormView(CSerialView::IDD)
{
	//{{AFX_DATA_INIT(CSerialView)
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CSerialView::~CSerialView()
{
}

void CSerialView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSerialView)
	DDX_Control(pDX, IDC_EDIT_CHECKFAULTS, m_CheckFaults);
	DDX_Control(pDX, IDC_EDIT_TempMon, m_TempMon);
	DDX_Control(pDX, IDC_EDIT_mAMON, m_maMon);
	DDX_Control(pDX, IDC_EDIT_KVmon, m_kvMon);
	DDX_Control(pDX, IDC_CHECK_XRAY, m_EnableXRay);
	DDX_Control(pDX, IDC_CHECK_mA, m_mAProgram);
	DDX_Control(pDX, IDC_CHECK_KV, m_kvProgram);
	DDX_Control(pDX, IDC_EDIT_VERSION, m_Version);
	DDX_Control(pDX, IDC_MSCOMM1, m_comm);
	//}}AFX_DATA_MAP
}

BOOL CSerialView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CSerialView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();
	// COM Port Initialisation 

	m_comm.SetCommPort(1);
	m_comm.SetSettings("9600,N,8,1");
	m_comm.SetInputLen(1);
	m_comm.SetInputMode(0);
	m_comm.SetPortOpen(true);

	CheckVersion();

	//This timer polls for feedback data and fault data. this is also used for watchdog purposes

	SetTimer(NULL,200,NULL);
}

/////////////////////////////////////////////////////////////////////////////
// CSerialView printing

BOOL CSerialView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CSerialView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CSerialView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CSerialView::OnPrint(CDC* pDC, CPrintInfo* /*pInfo*/)
{
	// TODO: add customized printing code here
}

/////////////////////////////////////////////////////////////////////////////
// CSerialView diagnostics

#ifdef _DEBUG
void CSerialView::AssertValid() const
{
	CFormView::AssertValid();
}

void CSerialView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CSerialDoc* CSerialView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSerialDoc)));
	return (CSerialDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSerialView message handlers

BEGIN_EVENTSINK_MAP(CSerialView, CFormView)
    //{{AFX_EVENTSINK_MAP(CSerialView)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()


void CSerialView::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	m_comm.SetPortOpen(false);
	CFormView::OnClose();
}


void CSerialView::OnCheckXray() 
{
	// TODO: Add your control notification handler code here
	while(InsideTimer){}

	ERROR_CHECK = FALSE;

	CString kVProgram = "",mAProgram = "",xRayOn = "";
	VARIANT in_dat;
	if(m_kvProgram.GetCheck() == TRUE)
		kVProgram = "\02VP0805\r";
	else
		kVProgram = "\02VP0000\r";

	if(m_mAProgram.GetCheck() == TRUE)
		mAProgram = "\02CP1100\r";
	else
		mAProgram = "\02CP0000\r";

	if(m_EnableXRay.GetCheck() == TRUE)
	{
		//KV Command
		m_comm.SetOutput(COleVariant(kVProgram));
		m_comm.SetInputLen(8);
		if(WaitForResponse(8) == FALSE)
		{
			AfxMessageBox("TimeOut...Restart Application");
		}
		in_dat = m_comm.GetInput();
		kVProgram = in_dat.bstrVal;
		
		//mACommand
		m_comm.SetOutput(COleVariant(mAProgram));
		m_comm.SetInputLen(8);
		if(WaitForResponse(8) == FALSE)
		{
			AfxMessageBox("TimeOut...Restart Application");
		}
		in_dat = m_comm.GetInput();
		mAProgram = in_dat.bstrVal;
		
		//xray enable
		xRayOn = "\02ENBL1\r";
		m_comm.SetOutput(COleVariant(xRayOn));
		m_comm.SetInputLen(7);
		if(WaitForResponse(7) == FALSE)
		{
			AfxMessageBox("TimeOut...Restart Application");
		}
		in_dat = m_comm.GetInput();
		xRayOn = in_dat.bstrVal;
	}
	else
	{
		//xray Disable
		xRayOn = "\02ENBL0\r";

		m_comm.SetOutput(COleVariant(xRayOn));

		m_comm.SetInputLen(7);
		if(WaitForResponse(7) == FALSE)
		{
			AfxMessageBox("TimeOut...Restart Application");
		}
		in_dat = m_comm.GetInput();
		xRayOn = in_dat.bstrVal;
	}

	ERROR_CHECK = TRUE;
}

void CSerialView::OnClearFaults() 
{
	// TODO: Add your control notification handler code here
	while(InsideTimer){}

	ERROR_CHECK = FALSE;

	//Clear Faults
	CString ClrFaults;
	VARIANT in_dat;

	ClrFaults = "\02CLR\r";
	m_comm.SetOutput(COleVariant(ClrFaults));

	m_comm.SetInputLen(5);
	if(WaitForResponse(5) == FALSE)
	{
		AfxMessageBox("TimeOut...Restart Application");
	}
	in_dat = m_comm.GetInput();
	ClrFaults = in_dat.bstrVal;

	ERROR_CHECK = TRUE;
}

CString CheckFaults,temp_Faults;
BOOL KillTmr = FALSE;

void CSerialView::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(ERROR_CHECK == TRUE && KillTmr == FALSE)
	{
		//Fault Monitor
		VARIANT in_data;
		InsideTimer = TRUE;
		CheckFaults = "\02FLT\r";
		m_comm.SetOutput(COleVariant(CheckFaults));

		m_comm.SetInputLen(19);
		
		if(WaitForResponse(19) == FALSE)
		{
		//	AfxMessageBox("TimeOut...Restart Application");
			KillTmr = TRUE;
		}
		else
		{
			in_data = m_comm.GetInput();
			CheckFaults = in_data.bstrVal;
			temp_Faults = "\02";
			temp_Faults = temp_Faults + "0 0 0 0 0 0 0 0 0\r";		
			
			m_CheckFaults.SetWindowText("");

			if(CheckFaults.Compare(temp_Faults) != 0)
				m_CheckFaults.SetWindowText("Error.Please Clear");
			else
				m_CheckFaults.SetWindowText("No Error");
		}
		

		///Monitor Feedback Values
		CString Mon;
		VARIANT in_dat;

		Mon = "\02MON\r";
		m_comm.SetOutput(COleVariant(Mon));

		m_comm.SetInputLen(21);
		
		if(WaitForResponse(21) == FALSE)
		{
		//	AfxMessageBox("TimeOut...Restart Application");
			KillTmr = TRUE;
		}
		else
		{
			in_dat = m_comm.GetInput();
			Mon = in_dat.bstrVal;
				
			CString temp;
			temp = Mon[1];
			temp = temp + Mon[2]; 
			temp = temp + Mon[3]; 
			temp = temp + ".";
			temp = temp + Mon[4];
			m_kvMon.SetWindowText(temp);

			temp = "";
			temp = Mon[6];
			temp = temp + Mon[7]; 
			temp = temp + Mon[8]; 
			temp = temp + Mon[9];
			m_maMon.SetWindowText(temp);
			
			temp = "";
			temp = Mon[11];
			temp = temp + Mon[12]; 
			temp = temp + Mon[13];
			temp = temp + ".";
			temp = temp + Mon[14];
			m_TempMon.SetWindowText(temp);
		}
		
	}
	InsideTimer = FALSE;
	CFormView::OnTimer(nIDEvent);
}

BOOL CSerialView::WaitForResponse(int BufferLength)
{
	int temp=0;
	while(m_comm.GetInBufferCount() !=BufferLength)
	{
		Sleep(1);
		temp++;
		if(temp >3700)
		{
			return FALSE;
		}
	}
	return TRUE;
}

void CSerialView::CheckVersion()
{
	ERROR_CHECK = FALSE;
	CString temp_version,temp_version1;
	VARIANT in_dat;
	
	
	temp_version = "\02FREV\r";
	m_comm.SetOutput(COleVariant(temp_version));
	m_comm.SetInputLen(6);
	if(WaitForResponse(6) == FALSE)
	{
		AfxMessageBox("TimeOut...Restart Application");
	}
	in_dat = m_comm.GetInput();
	temp_version1 = in_dat.bstrVal;
	
	temp_version = "\02";
	temp_version = temp_version + "2000\r";
	
	if(temp_version1.Compare(temp_version) == 0)
		temp_version1 = "2000";

	m_Version.SetWindowText(temp_version1);
	
	ERROR_CHECK = TRUE;
}